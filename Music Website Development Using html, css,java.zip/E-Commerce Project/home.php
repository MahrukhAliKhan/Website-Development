<?php
session_start();
?>

<html>
<head>
<title>Login Home</title>
</head>



<body>
Welcome

</body>
</html>