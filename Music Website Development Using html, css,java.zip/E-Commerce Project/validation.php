<?php
 session_start();
 
 
$con = mysqli_connect('localhost' , 'root');

mysqli_select_db($con, 'userregistration'); 

if (!$con) {
    die("Connection failed: " . mysqli_connect_error()); // this will direct same error on page
}


// could add submit , space(escape type) and single check and password does  not match error

$addr = $_POST['email'];
$pass = $_POST['pass'];
$s = " select * from usertable where email = '$addr' && password ='pass'";
$result = mysqli_query($con , $s);
$num = mysqli_num_rows($result);

//if($num == 1)
if($num > 0) // better version // incase you have not added match check
{
	header('location:home.php');
}
else
{
	header('location:login.php');
}

?>