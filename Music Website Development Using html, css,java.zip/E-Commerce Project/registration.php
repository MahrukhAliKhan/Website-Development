<?php
 session_start();
 
 
$con = mysqli_connect('localhost' , 'root');

mysqli_select_db($con, 'userregistration'); 

if (!$con) {
    die("Connection failed: " . mysqli_connect_error()); // this will direct same error on page
}


// could add submit , space(escape type) and single check and password does  not match error

$f_name = $_POST['fname'];
$l_name = $_POST['lname'];
$addr = $_POST['email'];
$pass = $_POST['pass'];
$C_pass = $_POST['password'];
$s = " select * from usertable where email = '$addr'";
$result = mysqli_query($con , $s);
$num = mysqli_num_rows($result);

//if($num == 1)
if($num > 0) // better version // incase you have not added match check
{
	echo " email /Username Already Taken";
}
else
{
	mysqli_query($con,"insert into usertable(fname,lname,email,password,con_password) values('$f_name' , '$l_name' , '$addr' , '$pass' , '$C_pass')");
	echo "\ninsert\n";
	echo "Registration Successful";
}

?>